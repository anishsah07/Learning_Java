import kfa.model.*;
import kfa.exception.*;
import kfa.service.*;

public class Main {
    public static void main(String[] args) {
        System.out.println(" Polymorphism and Hierarchy ");

        LibraryItem[] items = new LibraryItem[] {
                new Book("Clean Code", "9780132350884", 850.00),
                new Magazine("Tech Monthly", "9781234567897", 250.00, 42),
                new DVD("Inception", "9789876543210", 500.00, 148),
                new Book("Effective Java", "9780134685991", 1200.00)
        };


        for (LibraryItem item : items) {
            System.out.println(item.toString());
            System.out.println("Lending Period: " + item.getLendingPeriodDays() + " days\n");
        }
        System.out.println("Total Books Created: " + Book.getTotalBooks());



        System.out.println("\n Custom Exception Handling ");
        LibrarySystem system = new LibrarySystem();


        runBorrowTransaction(system, items[0]);


        runBorrowTransaction(system, items[0]);

        runReturnTransaction(system, items[1], 3);

        System.out.println("\n  String Utilities & StringBuilder ");


        System.out.println("Member ID: " + LibrarySystem.generateMemberId("Aarav Shrestha"));
        System.out.println("Member ID (Single Name): " + LibrarySystem.generateMemberId("Plato"));

        System.out.println("\n ISBN Validation Tests:");
        String[] testIsbns = {
                "9780132350884",
                "0123456789012",
                "978013235088",
                "978013235088X"
        };
        for (String isbn : testIsbns) {
            System.out.println("ISBN " + isbn + " -> Valid: " + LibrarySystem.isValidIsbn(isbn));
        }


        System.out.println("\nFull Report:");
        System.out.println(system.buildCatalogueReport(items, ""));

        System.out.println("Filtered Report (Keyword 'java'):");
        System.out.println(system.buildCatalogueReport(items, "java"));
    }

    private static void runBorrowTransaction(LibrarySystem system, LibraryItem item) {
        try {
            system.borrowItem(item);
            System.out.println("Successfully borrowed: " + item.getTitle());
        } catch (BookNotAvailableException e) {
            System.out.println("BORROW ERROR: " + e.getMessage());
        } finally {
            System.out.println("Transaction processed for: " + item.getTitle());
        }
    }

    private static void runReturnTransaction(LibrarySystem system, LibraryItem item, int daysLate) {
        try {
            system.returnItem(item, daysLate);
            System.out.println("Successfully returned: " + item.getTitle());
        } catch (ItemOverdueException e) {
            System.out.println("RETURN ERROR: " + e.getMessage());
        } finally {
            System.out.println("Transaction processed for: " + item.getTitle());
        }
    }
}