package kfa.model;

public class Book extends LibraryItem implements Renewable {
    private static int totalBooks = 0;

    public Book(String title, String isbn, double price) {
        super(title, isbn, price);
        totalBooks++;
    }

    public static int getTotalBooks() {

        return totalBooks;
    }

    @Override
    public int getLendingPeriodDays() {
        return 14;
    }

    @Override
    public void renew(int extraDays) {
        System.out.println("Book '" + getTitle() + "' renewed for an additional " + extraDays + " days.");
    }

    @Override
    public String toString() {
        return "[" + getIsbn() + "] " + getTitle() + " Rs " + String.format("%.2f", getPrice()) +
                " (" + (isAvailable() ? "Available" : "Borrowed") + ")";
    }
}