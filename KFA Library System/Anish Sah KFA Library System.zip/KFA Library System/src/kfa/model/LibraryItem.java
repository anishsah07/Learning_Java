package kfa.model;


public abstract class LibraryItem {
    private String title;
    private String isbn;
    private double price;
    private boolean available;

    public LibraryItem(String title, String isbn, double price) {
        this.title = title;
        this.isbn = isbn;
        setPrice(price);
        this.available = true;
    }

    public abstract int getLendingPeriodDays();

    public String getTitle() {
        return title;
    }
    public String getIsbn() {
        return isbn;
    }
    public double getPrice() {
        return price;
    }
    public boolean isAvailable() {

        return available;
    }

    public void setAvailable(boolean available) {

        this.available = available;
    }

    public void setPrice(double price) {
        if (price >= 0) {
            this.price = price;
        } else {
            System.out.println("Invalid Price: Price cannot be negative. Setting default to 0.0.");
            this.price = 0.0;
        }
    }
}