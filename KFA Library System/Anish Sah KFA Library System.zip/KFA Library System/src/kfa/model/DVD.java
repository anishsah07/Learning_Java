package kfa.model;

public class DVD extends LibraryItem implements Renewable {
    private int durationMinutes;

    public DVD(String title, String isbn, double price, int durationMinutes) {
        super(title, isbn, price);
        this.durationMinutes = durationMinutes;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    @Override
    public int getLendingPeriodDays() {
        return 5;
    }

    @Override
    public void renew(int extraDays) {
        System.out.println("DVD '" + getTitle() + "' renewed for an additional " + extraDays + " days.");
    }

    @Override
    public String toString() {
        return "[DVD " + durationMinutes + " mins] " + getTitle() + " Rs " + String.format("%.2f", getPrice()) +
                " (" + (isAvailable() ? "Available" : "Borrowed") + ")";
    }
}