package kfa.service;


import kfa.exception.*;
import kfa.model.*;
import java.util.Random;

public class LibrarySystem {

    public void borrowItem(LibraryItem item) throws BookNotAvailableException {
        if (!item.isAvailable()) {
            throw new BookNotAvailableException("The item '" + item.getTitle() + "' is currently out on loan.");
        }
        item.setAvailable(false);
    }

    public void returnItem(LibraryItem item, int daysLate) throws ItemOverdueException {
        if (daysLate > 0) {
            throw new ItemOverdueException(daysLate);
        }
        item.setAvailable(true);
    }


    public static String generateMemberId(String fullName) {
        if (fullName == null) return "";
        String trimmed = fullName.trim();
        String[] parts = trimmed.split(" ");

        String firstPart = "";
        String lastPart = "";

        if (parts.length == 1) {

            String single = parts[0].toUpperCase();
            firstPart = single.length() >= 3 ? single.substring(0, 3) : single;
            lastPart = single.length() >= 5 ? single.substring(3, 5) : "XX";
        } else {
            String firstName = parts[0].toUpperCase();
            String lastName = parts[parts.length - 1].toUpperCase();

            firstPart = firstName.length() >= 3 ? firstName.substring(0, 3) : firstName;
            lastPart = lastName.length() >= 2 ? lastName.substring(0, 2) : lastName;
        }

        int randomNum = new Random().nextInt(900) + 100;
        return firstPart + lastPart + randomNum;
    }


    public static boolean isValidIsbn(String isbn) {
        if (isbn == null || isbn.length() != 13) {
            return false;
        }
        if (isbn.charAt(0) == '0') {
            return false;
        }
        for (int i = 0; i < isbn.length(); i++) {
            if (!Character.isDigit(isbn.charAt(i))) {
                return false;
            }
        }
        return true;
    }


    public String buildCatalogueReport(LibraryItem[] items,   String filterKeyword) {
        StringBuilder sb = new StringBuilder();
        sb.append("===== KFA LIBRARY CATALOGUE REPORT =====\n");

        boolean hasKeyword = (filterKeyword != null && !filterKeyword.trim().isEmpty());
        String search = hasKeyword ? filterKeyword.trim().toLowerCase() : "";

        for (LibraryItem item : items) {
            if (!hasKeyword || item.getTitle().toLowerCase().contains(search)) {
                sb.append("- ").append(item.getTitle())
                        .append(" [Status: ").append(item.isAvailable() ? "Available" : "Borrowed").append("]")
                        .append(" | Lending Days: ").append(item.getLendingPeriodDays())
                        .append("\n");
            }
        }
        return sb.toString();
    }
}