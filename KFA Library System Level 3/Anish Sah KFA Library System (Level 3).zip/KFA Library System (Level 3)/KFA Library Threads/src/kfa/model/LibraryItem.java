package kfa.model;

import java.util.concurrent.atomic.AtomicInteger;

public abstract class LibraryItem {
    private String title;
    private String isbn;
    private double price;
    private boolean available;
    private int copiesAvailable = 3;
    private AtomicInteger atomicCopies = new AtomicInteger(3);

    public LibraryItem(String title, String isbn, double price) {
        this.title = title;
        this.isbn = isbn;
        setPrice(price);
        this.available = true;
    }

    public abstract int getLendingPeriodDays();

    public String getTitle() {
        return title;
    }

    public String getIsbn() {
        return isbn;
    }

    public double getPrice() {
        return price;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public void setPrice(double price) {
        if (price >= 0) {
            this.price = price;
        } else {
            System.out.println("Price cannot be negative! Setting to 0.");
            this.price = 0.0;
        }
    }

    public int getCopiesAvailable() {
        return copiesAvailable;
    }

    public void resetCopies(int count) {
        this.copiesAvailable = count;
        this.atomicCopies.set(count);
    }

    public boolean borrowCopyUnsafe() {
        if (copiesAvailable > 0) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            copiesAvailable--;
            return true;
        }
        return false;
    }

    public synchronized boolean borrowCopySynchronized() {
        if (copiesAvailable > 0) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            copiesAvailable--;
            return true;
        }
        return false;
    }

    public boolean borrowCopyAtomic() {
        while (true) {
            int current = atomicCopies.get();
            if (current <= 0) {
                return false;
            }
            if (atomicCopies.compareAndSet(current, current - 1)) {
                return true;
            }
        }
    }

    public int getAtomicCopiesAvailable() {
        return atomicCopies.get();
    }
}