package kfa.model;

public class Magazine extends LibraryItem {
    private int issueNo;

    public Magazine(String title, String isbn, double price, int issueNo) {
        super(title, isbn, price);
        this.issueNo = issueNo;
    }

    public int getIssueNo() {
        return issueNo;
    }

    @Override
    public int getLendingPeriodDays() {
        return 7;
    }

    @Override
    public String toString() {
        return "Magazine Issue #" + issueNo + ": " + getTitle() + " | Price: Rs " + getPrice();
    }
}