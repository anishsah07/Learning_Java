package kfa.service;

import java.util.ArrayList;

public class ReturnsCart {
    private final int capacity;
    private final ArrayList<String> items = new ArrayList<>();

    public ReturnsCart(int capacity) {
        this.capacity = capacity;
    }

    public synchronized void addReturn(String title) {
        while (items.size() == capacity) {
            try {
                System.out.println("[" + Thread.currentThread().getName() + "] Cart FULL. Waiting to deposit: " + title);
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        items.add(title);
        System.out.println("[" + Thread.currentThread().getName() + "] Deposited onto cart: " + title + " (Cart size: " + items.size() + ")");
        notifyAll();
    }

    public synchronized String collectReturn() {
        while (items.isEmpty()) {
            try {
                System.out.println("[" + Thread.currentThread().getName() + "] Cart EMPTY. Librarian waiting...");
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        String item = items.remove(0);
        System.out.println("[" + Thread.currentThread().getName() + "] Librarian collected: " + item + " (Cart size: " + items.size() + ")");
        notifyAll();
        return item;
    }
}