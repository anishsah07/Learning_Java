package kfa.service;

import java.util.Random;

public class KioskReturn implements Runnable {
    private ReturnsCart cart;
    private String[] itemsToReturn;

    public KioskReturn(ReturnsCart cart, String[] itemsToReturn) {
        this.cart = cart;
        this.itemsToReturn = itemsToReturn;
    }

    @Override
    public void run() {
        for (String item : itemsToReturn) {
            try {
                Thread.sleep(100 + new Random().nextInt(200));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            cart.addReturn(item);
        }
    }
}