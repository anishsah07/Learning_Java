package kfa.service;

import java.util.Random;

public class ReportWorker implements Runnable {
    private String reportType;

    public ReportWorker(String reportType) {
        this.reportType = reportType;
    }

    @Override
    public void run() {
        System.out.println("[" + Thread.currentThread().getName() + "] Report task '" + reportType + "' starting.");
        try {
            int delay = 600 + new Random().nextInt(800);
            Thread.sleep(delay);
        } catch (InterruptedException e) {
            System.out.println("[" + Thread.currentThread().getName() + "] Interrupted.");
        }
        System.out.println("[" + Thread.currentThread().getName() + "] Report task '" + reportType + "' completed.");
    }
}