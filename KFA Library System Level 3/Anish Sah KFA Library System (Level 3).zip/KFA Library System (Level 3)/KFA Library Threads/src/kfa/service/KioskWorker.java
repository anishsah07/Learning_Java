package kfa.service;

import java.util.Random;

public class KioskWorker extends Thread {
    private String kioskName;

    public KioskWorker(String kioskName) {
        super(kioskName);
        this.kioskName = kioskName;
    }

    @Override
    public void run() {
        System.out.println("[" + Thread.currentThread().getName() + "] Kiosk " + kioskName + " started checkout task.");
        try {
            int delay = 500 + new Random().nextInt(1001);
            Thread.sleep(delay);
        } catch (InterruptedException e) {
            System.out.println("[" + Thread.currentThread().getName() + "] Interrupted.");
        }
        System.out.println("[" + Thread.currentThread().getName() + "] Kiosk " + kioskName + " finished task.");
    }
}