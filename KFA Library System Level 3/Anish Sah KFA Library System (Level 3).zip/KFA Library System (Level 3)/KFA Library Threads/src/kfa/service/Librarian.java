package kfa.service;

public class Librarian implements Runnable {
    private ReturnsCart cart;
    private int totalToProcess;

    public Librarian(ReturnsCart cart, int totalToProcess) {
        this.cart = cart;
        this.totalToProcess = totalToProcess;
    }

    @Override
    public void run() {
        for (int i = 0; i < totalToProcess; i++) {
            cart.collectReturn();
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println("[Librarian] Finished processing all expected items for the shift.");
    }
}