package kfa.service;

import kfa.model.*;
import kfa.exception.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashMap;

public class LibrarySystem {

    private ArrayList<LibraryItem> catalogue = new ArrayList<>();
    private ArrayList<LibraryItem> removalHistory = new ArrayList<>();
    private Set<String> currentlyBorrowed = ConcurrentHashMap.newKeySet();
    private HashMap<String, Book> isbnIndex = new HashMap<>();

    public static String sanitizeTitle(String raw) {
        if (raw == null) return "";
        String temp = raw.trim();
        if (temp.equals("")) return "";

        String[] words = temp.split(" ");
        StringBuilder res = new StringBuilder();

        for (int i = 0; i < words.length; i++) {
            String w = words[i];
            if (w.length() > 0) {
                String cap = w.substring(0, 1).toUpperCase() + w.substring(1).toLowerCase();
                if (res.length() > 0) {
                    res.append(" ");
                }
                res.append(cap);
            }
        }
        return res.toString();
    }

    public static String generateReceiptText(String memberName, LibraryItem item) {
        StringBuilder sb = new StringBuilder();
        sb.append("--------------------------------\n");
        sb.append("        LIBRARY RECEIPT         \n");
        sb.append("--------------------------------\n");
        sb.append("Member: ").append(memberName).append("\n");
        sb.append("Item  : ").append(item.getTitle()).append("\n");
        sb.append("Due   : 14 Days from checkout\n");
        sb.append("--------------------------------\n");
        return sb.toString();
    }

    public static String placeOnShelf(String[][] shelves, String isbn) {
        for (int i = 0; i < shelves.length; i++) {
            for (int j = 0; j < shelves[i].length; j++) {
                if (shelves[i][j] == null || shelves[i][j].equals("")) {
                    shelves[i][j] = isbn;
                    return i + "," + j;
                }
            }
        }
        return "-1,-1";
    }

    public static void printShelves(String[][] shelves) {
        System.out.println("--- Current Shelves Grid ---");
        for (int i = 0; i < shelves.length; i++) {
            System.out.print("Shelf " + i + ": ");
            for (int j = 0; j < shelves[i].length; j++) {
                if (shelves[i][j] == null || shelves[i][j].equals("")) {
                    System.out.print("[Empty] ");
                } else {
                    System.out.print("[" + shelves[i][j] + "] ");
                }
            }
            System.out.println();
        }
    }

    public static Book findMostExpensive(Book[] books) {
        if (books == null || books.length == 0) return null;
        Book highest = books[0];
        for (int i = 1; i < books.length; i++) {
            if (books[i].getPrice() > highest.getPrice()) {
                highest = books[i];
            }
        }
        return highest;
    }

    public static void reverseInPlace(Book[] books) {
        if (books == null) return;
        int i = 0;
        int j = books.length - 1;
        while (i < j) {
            Book temp = books[i];
            books[i] = books[j];
            books[j] = temp;
            i++;
            j--;
        }
    }

    public void addItem(LibraryItem item) {
        catalogue.add(item);
        if (item instanceof Book) {
            isbnIndex.put(item.getIsbn(), (Book) item);
        }
    }

    public boolean removeItem(String isbn) {
        for (int i = 0; i < catalogue.size(); i++) {
            LibraryItem item = catalogue.get(i);
            if (item.getIsbn().equals(isbn)) {
                catalogue.remove(i);
                removalHistory.add(item);
                if (item instanceof Book) {
                    isbnIndex.remove(isbn);
                }
                return true;
            }
        }
        return false;
    }

    public void sortByPrice() {
        Collections.sort(catalogue, new Comparator<LibraryItem>() {
            @Override
            public int compare(LibraryItem item1, LibraryItem item2) {
                return Double.compare(item1.getPrice(), item2.getPrice());
            }
        });
    }

    public void sortByTitle() {
        Collections.sort(catalogue, (i1, i2) -> i1.getTitle().compareToIgnoreCase(i2.getTitle()));
    }

    public void displayCatalogue() {
        for (LibraryItem item : catalogue) {
            System.out.println("  " + item);
        }
    }

    public void undoRemove() {
        if (removalHistory.isEmpty()) {
            System.out.println("Nothing to undo!");
            return;
        }
        LibraryItem restored = removalHistory.remove(removalHistory.size() - 1);
        addItem(restored);
        System.out.println("Restored item: " + restored.getTitle());
    }

    public boolean borrowConcurrent(String isbn) {
        return currentlyBorrowed.add(isbn);
    }

    public boolean returnConcurrent(String isbn) {
        return currentlyBorrowed.remove(isbn);
    }

    public int getConcurrentBorrowedSize() {
        return currentlyBorrowed.size();
    }

    public Book findByIsbn(String isbn) {
        return isbnIndex.get(isbn);
    }
}