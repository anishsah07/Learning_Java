package kfa.service;

import kfa.model.LibraryItem;
import java.util.concurrent.Callable;

public class CopyCountTask implements Callable<Integer> {
    private LibraryItem[] catalogue;

    public CopyCountTask(LibraryItem[] catalogue) {
        this.catalogue = catalogue;
    }

    @Override
    public Integer call() throws Exception {
        int total = 0;
        for (LibraryItem item : catalogue) {
            total += item.getCopiesAvailable();
        }
        return total;
    }
}