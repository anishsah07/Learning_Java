import kfa.model.*;
import kfa.service.*;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
    public static void main(String[] args) throws Exception {

        System.out.println("==========================================");
        System.out.println("SECTION A: Thread Creation & Lifecycle");
        System.out.println("==========================================");

        KioskWorker kiosk1 = new KioskWorker("Alpha");
        KioskWorker kiosk2 = new KioskWorker("Beta");
        KioskWorker kiosk3 = new KioskWorker("Gamma");

        Thread rep1 = new Thread(new ReportWorker("Nightly Audit"), "ReportThread-1");
        Thread rep2 = new Thread(new ReportWorker("Inventory Check"), "ReportThread-2");

        kiosk1.setPriority(Thread.MAX_PRIORITY);
        kiosk2.setPriority(Thread.MIN_PRIORITY);

        System.out.println("kiosk1 State BEFORE start(): " + kiosk1.getState());
        kiosk1.start();
        kiosk2.start();
        kiosk3.start();
        rep1.start();
        rep2.start();
        System.out.println("kiosk1 State AFTER start() : " + kiosk1.getState());

        kiosk1.join();
        kiosk2.join();
        kiosk3.join();
        rep1.join();
        rep2.join();
        System.out.println("All KFA services closed for the night.\n");


        System.out.println("==========================================");
        System.out.println("SECTION B: Race Conditions & Synchronization");
        System.out.println("==========================================");

        Book testBook = new Book("Concurrent Java", "9780134685991", 1200.0);

        testBook.resetCopies(3);
        System.out.println("--- Test 1: Unsynchronized Borrow (3 initial copies, 10 threads) ---");
        Thread[] threadsB1 = new Thread[10];
        AtomicInteger successCountB1 = new AtomicInteger(0);

        for (int i = 0; i < 10; i++) {
            threadsB1[i] = new Thread(() -> {
                if (testBook.borrowCopyUnsafe()) {
                    successCountB1.incrementAndGet();
                }
            });
            threadsB1[i].start();
        }
        for (Thread t : threadsB1) t.join();

        System.out.println("Unsynchronized Success Count : " + successCountB1.get());
        System.out.println("Remaining Copies (Unsafe)    : " + testBook.getCopiesAvailable());

        testBook.resetCopies(3);
        System.out.println("\n--- Test 2: Synchronized Borrow (3 initial copies, 10 threads) ---");
        Thread[] threadsB2 = new Thread[10];
        AtomicInteger successCountB2 = new AtomicInteger(0);

        for (int i = 0; i < 10; i++) {
            threadsB2[i] = new Thread(() -> {
                if (testBook.borrowCopySynchronized()) {
                    successCountB2.incrementAndGet();
                }
            });
            threadsB2[i].start();
        }
        for (Thread t : threadsB2) t.join();

        System.out.println("Synchronized Success Count  : " + successCountB2.get());
        System.out.println("Remaining Copies (Safe)      : " + testBook.getCopiesAvailable());

        testBook.resetCopies(3);
        System.out.println("\n--- Test 3: AtomicInteger Borrow (3 initial copies, 10 threads) ---");
        Thread[] threadsB3 = new Thread[10];
        AtomicInteger successCountB3 = new AtomicInteger(0);

        for (int i = 0; i < 10; i++) {
            threadsB3[i] = new Thread(() -> {
                if (testBook.borrowCopyAtomic()) {
                    successCountB3.incrementAndGet();
                }
            });
            threadsB3[i].start();
        }
        for (Thread t : threadsB3) t.join();

        System.out.println("Atomic Success Count         : " + successCountB3.get());
        System.out.println("Remaining Atomic Copies      : " + testBook.getAtomicCopiesAvailable() + "\n");


        System.out.println("==========================================");
        System.out.println("SECTION C: Inter-Thread Communication");
        System.out.println("==========================================");

        ReturnsCart cart = new ReturnsCart(5);
        int totalItemsToProcess = 6;

        Librarian librarian = new Librarian(cart, totalItemsToProcess);
        Thread librarianThread = new Thread(librarian, "Librarian-Thread");

        String[] kiosk1Returns = {"Database Systems", "Design Patterns", "Clean Code"};
        String[] kiosk2Returns = {"Operating Systems", "Networking", "Compiler Principles"};

        Thread producer1 = new Thread(new KioskReturn(cart, kiosk1Returns), "KioskReturn-1");
        Thread producer2 = new Thread(new KioskReturn(cart, kiosk2Returns), "KioskReturn-2");

        librarianThread.start();
        producer1.start();
        producer2.start();

        producer1.join();
        producer2.join();
        librarianThread.join();
        System.out.println("Producer-Consumer Handoff Completed Successfully.\n");


        System.out.println("==========================================");
        System.out.println("SECTION D: Thread Pools & Concurrent Collections");
        System.out.println("==========================================");

        ExecutorService pool = Executors.newFixedThreadPool(4);

        System.out.println("Submitting 8 Kiosk tasks to FixedThreadPool(4)...");
        for (int i = 1; i <= 8; i++) {
            final int taskId = i;
            pool.submit(() -> {
                System.out.println("[" + Thread.currentThread().getName() + "] Processing Pool Task #" + taskId);
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
        }

        LibraryItem[] catalogArray = new LibraryItem[]{
                new Book("Physics", "9780001", 500.0),
                new Book("Chemistry", "9780002", 600.0),
                new DVD("Docu", "9780003", 200.0, 90)
        };
        catalogArray[0].resetCopies(5);
        catalogArray[1].resetCopies(4);
        catalogArray[2].resetCopies(2);

        Future<Integer> countFuture = pool.submit(new CopyCountTask(catalogArray));

        pool.shutdown();
        pool.awaitTermination(5, TimeUnit.SECONDS);

        System.out.println("Total Available Copies (via Callable Future): " + countFuture.get());

        LibrarySystem sys = new LibrarySystem();
        Thread[] borrowThreads = new Thread[10];

        for (int i = 0; i < 10; i++) {
            final String isbn = "ISBN-" + (i % 3);
            borrowThreads[i] = new Thread(() -> {
                sys.borrowConcurrent(isbn);
            });
            borrowThreads[i].start();
        }

        for (Thread t : borrowThreads) t.join();
        System.out.println("Final Concurrent Set Borrowed Size: " + sys.getConcurrentBorrowedSize() + " (Expected: 3 unique items)");
    }
}