package kfa.service;

import kfa.model.*;
import kfa.exception.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.HashMap;

public class LibrarySystem {

    // Section C collections
    private ArrayList<LibraryItem> catalogue = new ArrayList<>();
    private ArrayList<LibraryItem> removalHistory = new ArrayList<>();

    // Section D collections
    private HashSet<String> currentlyBorrowed = new HashSet<>();
    private HashMap<String, Book> isbnIndex = new HashMap<>();

    // A1: Sanitize title to Title Case using standard loop (no regex)
    public static String sanitizeTitle(String raw) {
        if (raw == null) return "";

        String temp = raw.trim();
        if (temp.equals("")) return "";

        String[] words = temp.split(" ");
        StringBuilder res = new StringBuilder();

        for (int i = 0; i < words.length; i++) {
            String w = words[i];
            if (w.length() > 0) {
                String cap = w.substring(0, 1).toUpperCase() + w.substring(1).toLowerCase();
                if (res.length() > 0) {
                    res.append(" ");
                }
                res.append(cap);
            }
        }
        return res.toString();
    }

    // A2: Formatted receipt output using StringBuilder
    public static String generateReceiptText(String memberName, LibraryItem item) {
        StringBuilder sb = new StringBuilder();
        sb.append("--------------------------------\n");
        sb.append("        LIBRARY RECEIPT         \n");
        sb.append("--------------------------------\n");
        sb.append("Member: ").append(memberName).append("\n");
        sb.append("Item  : ").append(item.getTitle()).append("\n");
        sb.append("Due   : 14 Days from checkout\n");
        sb.append("--------------------------------\n");
        return sb.toString();
    }

    // B1: Place item on 5x10 grid shelf
    public static String placeOnShelf(String[][] shelves, String isbn) {
        for (int i = 0; i < shelves.length; i++) {
            for (int j = 0; j < shelves[i].length; j++) {
                if (shelves[i][j] == null || shelves[i][j].equals("")) {
                    shelves[i][j] = isbn;
                    return i + "," + j;
                }
            }
        }
        return "-1,-1";
    }

    public static void printShelves(String[][] shelves) {
        System.out.println("--- Current Shelves Grid ---");
        for (int i = 0; i < shelves.length; i++) {
            System.out.print("Shelf " + i + ": ");
            for (int j = 0; j < shelves[i].length; j++) {
                if (shelves[i][j] == null || shelves[i][j].equals("")) {
                    System.out.print("[Empty] ");
                } else {
                    System.out.print("[" + shelves[i][j] + "] ");
                }
            }
            System.out.println();
        }
    }

    // B2: Manual scan for most expensive book
    public static Book findMostExpensive(Book[] books) {
        if (books == null || books.length == 0) return null;

        Book highest = books[0];
        for (int i = 1; i < books.length; i++) {
            if (books[i].getPrice() > highest.getPrice()) {
                highest = books[i];
            }
        }
        return highest;
    }

    // B2: In-place array reversal using temp variable
    public static void reverseInPlace(Book[] books) {
        if (books == null) return;

        int i = 0;
        int j = books.length - 1;
        while (i < j) {
            Book temp = books[i];
            books[i] = books[j];
            books[j] = temp;
            i++;
            j--;
        }
    }

    // C1: ArrayList catalogue functions
    public void addItem(LibraryItem item) {
        catalogue.add(item);
        if (item instanceof Book) {
            isbnIndex.put(item.getIsbn(), (Book) item);
        }
    }

    public boolean removeItem(String isbn) {
        for (int i = 0; i < catalogue.size(); i++) {
            LibraryItem item = catalogue.get(i);
            if (item.getIsbn().equals(isbn)) {
                catalogue.remove(i);
                removalHistory.add(item); // C3: push to undo history
                if (item instanceof Book) {
                    isbnIndex.remove(isbn);
                }
                return true;
            }
        }
        return false;
    }

    public ArrayList<LibraryItem> searchByTitle(String keyword) {
        ArrayList<LibraryItem> results = new ArrayList<>();
        String search = keyword.toLowerCase();
        for (LibraryItem item : catalogue) {
            if (item.getTitle().toLowerCase().contains(search)) {
                results.add(item);
            }
        }
        return results;
    }

    // C2: Custom Comparators for sorting
    public void sortByPrice() {
        Collections.sort(catalogue, new Comparator<LibraryItem>() {
            @Override
            public int compare(LibraryItem item1, LibraryItem item2) {
                if (item1.getPrice() < item2.getPrice()) return -1;
                if (item1.getPrice() > item2.getPrice()) return 1;
                return 0;
            }
        });
    }

    public void sortByTitle() {
        Collections.sort(catalogue, new Comparator<LibraryItem>() {
            @Override
            public int compare(LibraryItem item1, LibraryItem item2) {
                return item1.getTitle().compareToIgnoreCase(item2.getTitle());
            }
        });
    }

    public void displayCatalogue() {
        for (LibraryItem item : catalogue) {
            System.out.println("  " + item);
        }
    }

    // C3: Undo last removal
    public void undoRemove() {
        if (removalHistory.isEmpty()) {
            System.out.println("Nothing to undo!");
            return;
        }
        // pop last removed element
        int lastIdx = removalHistory.size() - 1;
        LibraryItem restored = removalHistory.remove(lastIdx);
        addItem(restored);
        System.out.println("Restored item: " + restored.getTitle());
    }

    // D1: HashSet duplicate borrow check
    public boolean borrow(String isbn) {
        return currentlyBorrowed.add(isbn);
    }

    public boolean returnBook(String isbn) {
        return currentlyBorrowed.remove(isbn);
    }

    // D2: Fast HashMap lookup
    /*
     * HashMap lookup takes O(1) time because it uses the ISBN hash code to jump straight to the object location.
     * Scanning an ArrayList takes O(N) time because it has to iterate through every item one by one.
     */
    public Book findByIsbn(String isbn) {
        return isbnIndex.get(isbn);
    }

    // D3: Borrow log analysis using getOrDefault
    public static void printMostBorrowedReport(String[] log) {
        HashMap<String, Integer> counts = new HashMap<>();

        for (int i = 0; i < log.length; i++) {
            String title = log[i];
            int current = counts.getOrDefault(title, 0);
            counts.put(title, current + 1);
        }

        String mostPopular = "";
        int max = 0;

        for (String title : counts.keySet()) {
            int count = counts.get(title);
            if (count > max) {
                max = count;
                mostPopular = title;
            }
        }

        System.out.println("Most Borrowed Title: " + mostPopular + " (" + max + " times)");
    }
}