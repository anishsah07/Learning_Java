package kfa.model;

// Magazine deliberately does not implement Renewable so that current issues are always available to other readers
public class Magazine extends LibraryItem {
    private int issueNo;

    public Magazine(String title, String isbn, double price, int issueNo) {
        super(title, isbn, price);
        this.issueNo = issueNo;
    }

    public int getIssueNo() {
        return issueNo;
    }

    @Override
    public int getLendingPeriodDays() {
        return 7; // magazines are 1 week loan
    }

    @Override
    public String toString() {
        return "Magazine Issue #" + issueNo + ": " + getTitle() + " | Price: Rs " + getPrice();
    }
}