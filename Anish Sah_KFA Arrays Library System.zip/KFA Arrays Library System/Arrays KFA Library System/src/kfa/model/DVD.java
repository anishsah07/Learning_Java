package kfa.model;

public class DVD extends LibraryItem implements Renewable {
    private int runtime; // in minutes

    public DVD(String title, String isbn, double price, int runtime) {
        super(title, isbn, price);
        this.runtime = runtime;
    }

    public int getRuntime() {
        return runtime;
    }

    @Override
    public int getLendingPeriodDays() {
        return 5;
    }

    @Override
    public void renew(int extraDays) {
        System.out.println("Renewed DVD " + getTitle() + " for " + extraDays + " days.");
    }

    @Override
    public String toString() {
        return "DVD (" + runtime + " mins): " + getTitle() + " | Price: Rs " + getPrice();
    }
}