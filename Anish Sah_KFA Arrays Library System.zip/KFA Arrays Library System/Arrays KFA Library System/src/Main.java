import kfa.model.*;
import kfa.service.*;

public class Main {
    public static void main(String[] args) {

        System.out.println(" SECTION A ");
        // A1: String cleaning
        String messy = "   tHe   LOrD  oF  tHe  rInGs   ";
        System.out.println("Original : '" + messy + "'");
        System.out.println("Cleaned  : '" + LibrarySystem.sanitizeTitle(messy) + "'");

        // A2: Receipt & String comparison test
        Book testBook = new Book("Harry Potter", "9780747532699", 750.0);
        System.out.println("\n" + LibrarySystem.generateReceiptText("Rohan Sharma", testBook));

        String str1 = "9780747532699";
        String str2 = new String("9780747532699");

        System.out.println("Testing String equality:");
        System.out.println("str1 == str2      : " + (str1 == str2));
        System.out.println("str1.equals(str2) : " + str1.equals(str2));


        System.out.println("\n SECTION B ");
        // B1: 5x10 Grid Test
        String[][] shelves = new String[5][10];
        for (int r = 0; r < 5; r++) {
            for (int c = 0; c < 10; c++) {
                shelves[r][c] = "";
            }
        }

        LibrarySystem.placeOnShelf(shelves, "9780747532699");
        LibrarySystem.placeOnShelf(shelves, "9780345339706");
        LibrarySystem.printShelves(shelves);

        // B2: Array reverse and highest price scan
        Book[] myBooks = new Book[] {
                new Book("Book A", "9783111111111", 400.0),
                new Book("Book B", "9783222222222", 1200.0),
                new Book("Book C", "9783333333333", 850.0),
                new Book("Book D", "9783444444444", 300.0),
                new Book("Book E", "9785555555555", 950.0)
        };

        System.out.println("\nMost expensive book: " + LibrarySystem.findMostExpensive(myBooks));

        System.out.println("\nBefore reversal:");
        for (Book b : myBooks) {
            System.out.println(" -> " + b.getTitle());
        }

        LibrarySystem.reverseInPlace(myBooks);

        System.out.println("After reversal:");
        for (Book b : myBooks) {
            System.out.println(" -> " + b.getTitle());
        }


        System.out.println("\n SECTION C ");
        LibrarySystem lib = new LibrarySystem();

        Book b1 = new Book("Java Basics", "9780134685991", 650.0);
        Book b2 = new Book("Algorithms", "9780262033848", 1500.0);
        Magazine m1 = new Magazine("Science Daily", "9789999999999", 200.0, 15);
        DVD d1 = new DVD("The Matrix", "9788888883456", 500.0, 136);

        lib.addItem(b1);
        lib.addItem(b2);
        lib.addItem(m1);
        lib.addItem(d1);

        System.out.println("\n Sorted by Price ");
        lib.sortByPrice();
        lib.displayCatalogue();

        System.out.println("\n Sorted by Title ");
        lib.sortByTitle();
        lib.displayCatalogue();

        System.out.println("\nRemoving 'Algorithms");
        lib.removeItem("9780262033848");
        lib.displayCatalogue();

        System.out.println("\nTesting Undo");
        lib.undoRemove();
        lib.displayCatalogue();


        System.out.println("\n SECTION D ");
        // D1: Double-borrow check
        String isbnCheck = "9780134685991";
        System.out.println("Borrow 1st time : " + lib.borrow(isbnCheck));
        System.out.println("Borrow 2nd time : " + lib.borrow(isbnCheck)); // should return false
        System.out.println("Return book     : " + lib.returnBook(isbnCheck));
        System.out.println("Borrow again    : " + lib.borrow(isbnCheck));

        // D2: HashMap lookup
        System.out.println("\nMap lookup for ISBN 9780134685991:");
        System.out.println(lib.findByIsbn("9780134685991"));

        // D3: Popular book count report
        String[] logs = {
                "Java Basics", "The Matrix", "Java Basics",
                "Algorithms", "Java Basics", "The Matrix"
        };
        System.out.println();
        LibrarySystem.printMostBorrowedReport(logs);
    }
}